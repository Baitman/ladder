import os

import h5py
import numpy as np
import pickle
from fuel.converters.base import fill_hdf5_file


def convert_kdd(directory,output_file):
    output_path = os.path.join(directory, output_file)
    h5file = h5py.File(output_path, mode='w')
    classes = {'warezclient':0,'normal':1,'neptune':2,'back':3,'ipsweep':4,'teardrop':5,'satan':6,'smurf':7,'portsweep':8}
    data = pickle.load(open('/home/ncat/all_data.pickle2'))
    #        os.path.join(directory, A'all_data.pickle2'))
    # converters={-1: lambda x: classes[x]},
    #delimiter=',')
    features = []
    targets = []
    np.random.shuffle(data)


    #FILE = pickle.load(open('/home/ncat/all_data.pickle2','r'))
    X = []
    y = []
    for value,label in data:
        X.append(value)
        y.append(label)
        
    X = np.array(X)
    y = np.array(y)
    features = X
    targets = y
 
      
    train_features = features[:3094]
    train_targets = targets[:3094]

    test_features = features[3094:4494]
    test_targets = targets[3094:4494]
    data = (('train', 'features', train_features),
            ('train', 'targets', train_targets),
            ('test', 'features', test_features),
            ('test','targets',test_targets)) 
    fill_hdf5_file(h5file, data)
   # h5file['features'].dims[0].label = 'batch'
    #h5file['features'].dims[1].label = 'feature'
    #h5file['targets'].dims[0].label = 'batch'
    #h5file['targets'].dims[1].label = 'index'
    
    h5file.flush()
    h5file.close()

    

def fill_subparser(subparser):
    subparser.set_defaults(func= convert_kdd)
