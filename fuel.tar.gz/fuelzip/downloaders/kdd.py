from fuel.downloaders.base import default_downloader

def fill_subparser(subparser):
    subparser.set_defaults(func = default_downloader,
        urls=['http://kdd.ics.uci.edu/databases/kddcup99/kddcup.data_10_percent.gz'],filenames=['kddcup.data_10_percent.gz'])
    return default_downloader
