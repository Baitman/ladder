import os
from fuel.datasets import H5PYDataset
from fuel import config


class kdd(H5PYDataset):
    filename = 'kdd.hdf5'

    def __init__(self, which_set, **kwargs):
        kwargs.setdefault('load_in_memory', True)
        super(kdd, self).__init__(self.data_path,
            which_set, **kwargs)
    @property
    def data_path(self):
        return os.path.join(config.data_path, self.filename)
